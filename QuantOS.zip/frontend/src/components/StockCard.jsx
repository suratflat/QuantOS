
export default function StockCard({ stock }) {
  return (
    <div style={{border:"1px solid #444", margin:10, padding:10}}>
      <h3>{stock.ticker}</h3>
      <p>Price: ₹{stock.price}</p>
      <p>Change: {stock.dayChange}%</p>
      <p>Sector: {stock.sector}</p>
      <p>Score: {stock.score}</p>
    </div>
  );
}
