
import { useEffect, useState } from "react";
import axios from "axios";
import StockCard from "./components/StockCard";

export default function App() {
  const [stocks, setStocks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios.get("http://localhost:8000/api/scan", {
      params: { tickers: "RELIANCE.NS,TCS.NS,INFY.NS" }
    }).then(res => {
      setStocks(res.data.results);
      setLoading(false);
    });
  }, []);

  if (loading) return <div style={{padding:20}}>Scanning Market...</div>;

  return (
    <div style={{padding:20}}>
      <h1>QuantOS Dashboard</h1>
      {stocks.map(s => <StockCard key={s.ticker} stock={s} />)}
    </div>
  );
}
